import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';
import express from 'express';
import type { NextFunction, Request, Response } from 'express';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function resolvePort(): number {
  const portFlagIndex = process.argv.indexOf('--port');
  if (portFlagIndex !== -1 && process.argv[portFlagIndex + 1]) {
    const parsed = Number(process.argv[portFlagIndex + 1]);
    if (Number.isInteger(parsed) && parsed > 0) return parsed;
  }
  return Number(process.env.PORT || 3000);
}

const PORT = resolvePort();
const DB_PATH = path.join(__dirname, 'db.sqlite3');

// ---------------------------------------------------------------------------
// SQLite Database Initialization (Django-compatible schema)
// ---------------------------------------------------------------------------
const db = new DatabaseSync(DB_PATH);
db.exec('PRAGMA journal_mode = WAL;');
db.exec('PRAGMA foreign_keys = ON;');

db.exec(`
  CREATE TABLE IF NOT EXISTS auth_user (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE COLLATE NOCASE,
    email TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'Admin',
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS authtoken_token (
    key TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES auth_user(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS students_student (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    roll_number TEXT NOT NULL UNIQUE COLLATE NOCASE,
    email TEXT NOT NULL UNIQUE COLLATE NOCASE,
    department TEXT NOT NULL,
    year INTEGER NOT NULL CHECK(year >= 1 AND year <= 4),
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS app_meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );
`);

function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

function verifyPassword(password: string, storedHash: string): boolean {
  const [salt, keyHex] = storedHash.split(':');
  if (!salt || !keyHex) return false;
  const derived = crypto.scryptSync(password, salt, 64);
  const storedBuf = Buffer.from(keyHex, 'hex');
  if (derived.length !== storedBuf.length) return false;
  return crypto.timingSafeEqual(derived, storedBuf);
}

// Seed default admin account if missing
const existingAdmin = db.prepare('SELECT id FROM auth_user WHERE username = ?').get('admin') as
  | { id: number }
  | undefined;

if (!existingAdmin) {
  const defaultPassword = process.env.ADMIN_DEFAULT_PASSWORD || 'admin123';
  db.prepare(
    'INSERT INTO auth_user (username, email, password_hash, role, created_at) VALUES (?, ?, ?, ?, ?)'
  ).run('admin', 'admin@scholardesk.edu', hashPassword(defaultPassword), 'Admin', new Date().toISOString());
}

// Seed initial sample students once so beginners see a working directory immediately
const seededFlag = db.prepare("SELECT value FROM app_meta WHERE key = 'initial_seed_v1'").get() as
  | { value: string }
  | undefined;

if (!seededFlag) {
  const countRow = db.prepare('SELECT COUNT(*) AS count FROM students_student').get() as { count: number };
  if (countRow.count === 0) {
    const initialStudents = [
      {
        name: 'Aarav Sharma',
        roll_number: 'CS2026-001',
        email: 'aarav.sharma@university.edu',
        department: 'Computer Science',
        year: 3,
      },
      {
        name: 'Maya Lin',
        roll_number: 'CS2026-014',
        email: 'maya.lin@university.edu',
        department: 'Computer Science',
        year: 2,
      },
      {
        name: 'Liam OConnor',
        roll_number: 'EC2026-008',
        email: 'liam.oconnor@university.edu',
        department: 'Electronics & Comm.',
        year: 4,
      },
      {
        name: 'Priya Nair',
        roll_number: 'IT2026-019',
        email: 'priya.nair@university.edu',
        department: 'Information Technology',
        year: 1,
      },
      {
        name: 'Mateo Alvarez',
        roll_number: 'ME2026-005',
        email: 'mateo.alvarez@university.edu',
        department: 'Mechanical Engineering',
        year: 3,
      },
      {
        name: 'Sofia Patel',
        roll_number: 'CE2026-011',
        email: 'sofia.patel@university.edu',
        department: 'Civil Engineering',
        year: 2,
      },
      {
        name: 'Noah Kim',
        roll_number: 'IT2026-027',
        email: 'noah.kim@university.edu',
        department: 'Information Technology',
        year: 4,
      },
      {
        name: 'Elena Rostova',
        roll_number: 'CS2026-032',
        email: 'elena.rostova@university.edu',
        department: 'Computer Science',
        year: 1,
      },
    ];

    const insertStmt = db.prepare(`
      INSERT INTO students_student (name, roll_number, email, department, year, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);

    const now = Date.now();
    initialStudents.forEach((student, index) => {
      const ts = new Date(now - (initialStudents.length - index) * 3600_000).toISOString();
      insertStmt.run(
        student.name,
        student.roll_number,
        student.email,
        student.department,
        student.year,
        ts,
        ts
      );
    });
  }

  db.prepare("INSERT OR REPLACE INTO app_meta (key, value) VALUES ('initial_seed_v1', 'done')").run();
}

// ---------------------------------------------------------------------------
// Types & Auth Helpers
// ---------------------------------------------------------------------------
interface AuthUser {
  id: number;
  username: string;
  email: string;
  role: string;
}

interface AuthedRequest extends Request {
  adminUser?: AuthUser;
  authToken?: string;
}

interface StudentRow {
  id: number;
  name: string;
  roll_number: string;
  email: string;
  department: string;
  year: number;
  created_at: string;
  updated_at: string;
}

function parseCookies(cookieHeader: string | undefined): Record<string, string> {
  if (!cookieHeader) return {};
  const result: Record<string, string> = {};
  for (const part of cookieHeader.split(';')) {
    const idx = part.indexOf('=');
    if (idx > -1) {
      const key = part.slice(0, idx).trim();
      const val = part.slice(idx + 1).trim();
      if (key) {
        try {
          result[key] = decodeURIComponent(val);
        } catch {
          result[key] = val;
        }
      }
    }
  }
  return result;
}

function extractToken(req: Request): string | null {
  const authHeader = req.headers.authorization;
  if (authHeader) {
    if (authHeader.startsWith('Token ')) {
      return authHeader.slice(6).trim();
    }
    if (authHeader.startsWith('Bearer ')) {
      return authHeader.slice(7).trim();
    }
  }
  const cookies = parseCookies(req.headers.cookie);
  return cookies.sms_token || null;
}

function requireAdmin(req: AuthedRequest, res: Response, next: NextFunction): void {
  const token = extractToken(req);
  if (!token) {
    res.status(401).json({ detail: 'Authentication credentials were not provided.' });
    return;
  }

  const row = db
    .prepare(
      `SELECT u.id, u.username, u.email, u.role
       FROM authtoken_token t
       JOIN auth_user u ON u.id = t.user_id
       WHERE t.key = ?`
    )
    .get(token) as AuthUser | undefined;

  if (!row) {
    res.status(401).json({ detail: 'Invalid or expired session token. Please log in again.' });
    return;
  }

  req.adminUser = row;
  req.authToken = token;
  next();
}

// ---------------------------------------------------------------------------
// Validation Helpers (mirrors DRF StudentSerializer)
// ---------------------------------------------------------------------------
interface ValidationResult {
  valid: boolean;
  errors: Record<string, string[]>;
  cleaned?: {
    name: string;
    roll_number: string;
    email: string;
    department: string;
    year: number;
  };
}

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const ROLL_REGEX = /^[A-Z0-9][A-Z0-9\-/]{1,30}$/;

function validateStudentInput(
  payload: Record<string, unknown>,
  existingStudent?: StudentRow,
  isPartial = false
): ValidationResult {
  const errors: Record<string, string[]> = {};

  const rawName = payload.name !== undefined ? String(payload.name) : existingStudent?.name ?? '';
  const rawRoll =
    payload.roll_number !== undefined
      ? String(payload.roll_number)
      : existingStudent?.roll_number ?? '';
  const rawEmail = payload.email !== undefined ? String(payload.email) : existingStudent?.email ?? '';
  const rawDept =
    payload.department !== undefined ? String(payload.department) : existingStudent?.department ?? '';
  const rawYear = payload.year !== undefined ? payload.year : existingStudent?.year;

  const name = rawName.trim();
  const roll_number = rawRoll.trim().toUpperCase();
  const email = rawEmail.trim().toLowerCase();
  const department = rawDept.trim();
  const year = typeof rawYear === 'number' ? rawYear : Number.parseInt(String(rawYear ?? ''), 10);

  if (!isPartial || payload.name !== undefined) {
    if (!name) {
      errors.name = ['Student name is required.'];
    } else if (name.length < 2) {
      errors.name = ['Student name must be at least 2 characters long.'];
    } else if (name.length > 120) {
      errors.name = ['Student name cannot exceed 120 characters.'];
    }
  }

  if (!isPartial || payload.roll_number !== undefined) {
    if (!roll_number) {
      errors.roll_number = ['Roll number is required.'];
    } else if (!ROLL_REGEX.test(roll_number)) {
      errors.roll_number = [
        'Roll number must be 2–31 characters using letters, numbers, hyphens, or slashes (e.g., CS2026-001).',
      ];
    } else {
      const duplicateRoll = existingStudent
        ? db
            .prepare('SELECT id FROM students_student WHERE roll_number = ? AND id != ?')
            .get(roll_number, existingStudent.id)
        : db.prepare('SELECT id FROM students_student WHERE roll_number = ?').get(roll_number);

      if (duplicateRoll) {
        errors.roll_number = ['A student with this roll number already exists.'];
      }
    }
  }

  if (!isPartial || payload.email !== undefined) {
    if (!email) {
      errors.email = ['Email address is required.'];
    } else if (!EMAIL_REGEX.test(email)) {
      errors.email = ['Please enter a valid email address (e.g., name@university.edu).'];
    } else {
      const duplicateEmail = existingStudent
        ? db
            .prepare('SELECT id FROM students_student WHERE email = ? AND id != ?')
            .get(email, existingStudent.id)
        : db.prepare('SELECT id FROM students_student WHERE email = ?').get(email);

      if (duplicateEmail) {
        errors.email = ['A student with this email address already exists.'];
      }
    }
  }

  if (!isPartial || payload.department !== undefined) {
    if (!department) {
      errors.department = ['Department is required.'];
    } else if (department.length > 80) {
      errors.department = ['Department name cannot exceed 80 characters.'];
    }
  }

  if (!isPartial || payload.year !== undefined) {
    if (!Number.isInteger(year) || year < 1 || year > 4) {
      errors.year = ['Academic year must be between 1 and 4 (1st to 4th Year).'];
    }
  }

  if (Object.keys(errors).length > 0) {
    return { valid: false, errors };
  }

  return {
    valid: true,
    errors: {},
    cleaned: {
      name,
      roll_number,
      email,
      department,
      year,
    },
  };
}

// ---------------------------------------------------------------------------
// Express Application & REST API Routes
// ---------------------------------------------------------------------------
async function createApp() {
  const app = express();
  app.use(express.json());

  // Health check
  app.get('/api/health/', (_req, res) => {
    res.json({ status: 'ok', database: 'sqlite3' });
  });

  // POST /api/auth/login/
  app.post(['/api/auth/login/', '/api/auth/login'], (req: Request, res: Response) => {
    const username = typeof req.body?.username === 'string' ? req.body.username.trim() : '';
    const password = typeof req.body?.password === 'string' ? req.body.password : '';

    const fieldErrors: Record<string, string[]> = {};
    if (!username) fieldErrors.username = ['Username is required.'];
    if (!password) fieldErrors.password = ['Password is required.'];

    if (Object.keys(fieldErrors).length > 0) {
      res.status(400).json({
        ...fieldErrors,
        detail: 'Please enter both your admin username and password.',
      });
      return;
    }

    const user = db
      .prepare('SELECT id, username, email, password_hash, role FROM auth_user WHERE username = ?')
      .get(username) as
      | (AuthUser & { password_hash: string })
      | undefined;

    if (!user || !verifyPassword(password, user.password_hash)) {
      res.status(401).json({
        detail: 'Invalid username or password. Please check your admin credentials.',
      });
      return;
    }

    const token = crypto.randomBytes(24).toString('hex');
    db.prepare('INSERT INTO authtoken_token (key, user_id, created_at) VALUES (?, ?, ?)').run(
      token,
      user.id,
      new Date().toISOString()
    );

    res.setHeader(
      'Set-Cookie',
      `sms_token=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=86400`
    );

    res.json({
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
      },
    });
  });

  // POST /api/auth/logout/
  app.post(['/api/auth/logout/', '/api/auth/logout'], requireAdmin, (req: AuthedRequest, res: Response) => {
    if (req.authToken) {
      db.prepare('DELETE FROM authtoken_token WHERE key = ?').run(req.authToken);
    }
    res.setHeader('Set-Cookie', 'sms_token=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0');
    res.json({ detail: 'Signed out successfully.' });
  });

  // GET /api/auth/me/
  app.get(['/api/auth/me/', '/api/auth/me'], requireAdmin, (req: AuthedRequest, res: Response) => {
    res.json({ user: req.adminUser });
  });

  // GET /api/students/stats/
  app.get(['/api/students/stats/', '/api/students/stats'], requireAdmin, (_req: AuthedRequest, res: Response) => {
    const totalRow = db.prepare('SELECT COUNT(*) AS count FROM students_student').get() as {
      count: number;
    };
    const departments = db
      .prepare(
        `SELECT department, COUNT(*) AS count
         FROM students_student
         GROUP BY department
         ORDER BY count DESC, department ASC`
      )
      .all() as { department: string; count: number }[];
    const years = db
      .prepare(
        `SELECT year, COUNT(*) AS count
         FROM students_student
         GROUP BY year
         ORDER BY year ASC`
      )
      .all() as { year: number; count: number }[];

    res.json({
      total_students: totalRow.count,
      department_count: departments.length,
      departments,
      years,
    });
  });

  // GET /api/students/ (with ?search=, ?department=, ?year=)
  app.get(['/api/students/', '/api/students'], requireAdmin, (req: AuthedRequest, res: Response) => {
    const search = typeof req.query.search === 'string' ? req.query.search.trim() : '';
    const department = typeof req.query.department === 'string' ? req.query.department.trim() : '';
    const yearParam = typeof req.query.year === 'string' ? req.query.year.trim() : '';

    const conditions: string[] = [];
    const params: (string | number)[] = [];

    if (search) {
      conditions.push('(name LIKE ? OR roll_number LIKE ?)');
      const likeTerm = `%${search}%`;
      params.push(likeTerm, likeTerm);
    }

    if (department && department !== 'all') {
      conditions.push('LOWER(department) = LOWER(?)');
      params.push(department);
    }

    if (yearParam && yearParam !== 'all') {
      const parsedYear = Number.parseInt(yearParam, 10);
      if (Number.isInteger(parsedYear) && parsedYear >= 1 && parsedYear <= 4) {
        conditions.push('year = ?');
        params.push(parsedYear);
      }
    }

    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
    const rows = db
      .prepare(
        `SELECT id, name, roll_number, email, department, year, created_at, updated_at
         FROM students_student
         ${whereClause}
         ORDER BY datetime(created_at) DESC, id DESC`
      )
      .all(...params) as unknown as StudentRow[];

    const totalRow = db.prepare('SELECT COUNT(*) AS count FROM students_student').get() as {
      count: number;
    };

    res.json({
      count: rows.length,
      total_count: totalRow.count,
      results: rows,
    });
  });

  // POST /api/students/
  app.post(['/api/students/', '/api/students'], requireAdmin, (req: AuthedRequest, res: Response) => {
    const payload = (req.body && typeof req.body === 'object' ? req.body : {}) as Record<string, unknown>;
    const validation = validateStudentInput(payload);

    if (!validation.valid || !validation.cleaned) {
      res.status(400).json({
        ...validation.errors,
        detail: 'Please fix the validation errors below.',
      });
      return;
    }

    const { name, roll_number, email, department, year } = validation.cleaned;
    const now = new Date().toISOString();

    const info = db
      .prepare(
        `INSERT INTO students_student (name, roll_number, email, department, year, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?)`
      )
      .run(name, roll_number, email, department, year, now, now);

    const created = db
      .prepare(
        'SELECT id, name, roll_number, email, department, year, created_at, updated_at FROM students_student WHERE id = ?'
      )
      .get(Number(info.lastInsertRowid)) as unknown as StudentRow;

    res.status(201).json(created);
  });

  // GET /api/students/:id/
  app.get(['/api/students/:id/', '/api/students/:id'], requireAdmin, (req: AuthedRequest, res: Response) => {
    const id = Number.parseInt(String(req.params.id), 10);
    if (!Number.isInteger(id) || id <= 0) {
      res.status(404).json({ detail: 'Student record not found.' });
      return;
    }

    const student = db
      .prepare(
        'SELECT id, name, roll_number, email, department, year, created_at, updated_at FROM students_student WHERE id = ?'
      )
      .get(id) as StudentRow | undefined;

    if (!student) {
      res.status(404).json({ detail: 'Student record not found.' });
      return;
    }

    res.json(student);
  });

  // PUT / PATCH /api/students/:id/
  const handleUpdate = (req: AuthedRequest, res: Response) => {
    const id = Number.parseInt(String(req.params.id), 10);
    if (!Number.isInteger(id) || id <= 0) {
      res.status(404).json({ detail: 'Student record not found.' });
      return;
    }

    const existing = db
      .prepare(
        'SELECT id, name, roll_number, email, department, year, created_at, updated_at FROM students_student WHERE id = ?'
      )
      .get(id) as StudentRow | undefined;

    if (!existing) {
      res.status(404).json({ detail: 'Student record not found.' });
      return;
    }

    const isPartial = req.method === 'PATCH';
    const payload = (req.body && typeof req.body === 'object' ? req.body : {}) as Record<string, unknown>;
    const validation = validateStudentInput(payload, existing, isPartial);

    if (!validation.valid || !validation.cleaned) {
      res.status(400).json({
        ...validation.errors,
        detail: 'Please fix the validation errors below.',
      });
      return;
    }

    const { name, roll_number, email, department, year } = validation.cleaned;
    const now = new Date().toISOString();

    db.prepare(
      `UPDATE students_student
       SET name = ?, roll_number = ?, email = ?, department = ?, year = ?, updated_at = ?
       WHERE id = ?`
    ).run(name, roll_number, email, department, year, now, id);

    const updated = db
      .prepare(
        'SELECT id, name, roll_number, email, department, year, created_at, updated_at FROM students_student WHERE id = ?'
      )
      .get(id) as unknown as StudentRow;

    res.json(updated);
  };

  app.put(['/api/students/:id/', '/api/students/:id'], requireAdmin, handleUpdate);
  app.patch(['/api/students/:id/', '/api/students/:id'], requireAdmin, handleUpdate);

  // DELETE /api/students/:id/
  app.delete(['/api/students/:id/', '/api/students/:id'], requireAdmin, (req: AuthedRequest, res: Response) => {
    const id = Number.parseInt(String(req.params.id), 10);
    if (!Number.isInteger(id) || id <= 0) {
      res.status(404).json({ detail: 'Student record not found.' });
      return;
    }

    const result = db.prepare('DELETE FROM students_student WHERE id = ?').run(id);
    if (result.changes === 0) {
      res.status(404).json({ detail: 'Student record not found.' });
      return;
    }

    res.status(200).json({ detail: 'Student record deleted.' });
  });

  // GET /api/django-reference/ — Serves the real Django + DRF source files in /django_backend/
  app.get(['/api/django-reference/', '/api/django-reference'], requireAdmin, (_req: AuthedRequest, res: Response) => {
    const djangoDir = path.join(__dirname, 'django_backend');
    const filePaths = [
      'README.md',
      'requirements.txt',
      'sms_project/settings.py',
      'sms_project/urls.py',
      'students/models.py',
      'students/serializers.py',
      'students/views.py',
      'students/urls.py',
      'students/admin.py',
    ];

    const files = filePaths
      .map((rel) => {
        const abs = path.join(djangoDir, rel);
        if (!fs.existsSync(abs)) return null;
        return {
          path: `django_backend/${rel}`,
          content: fs.readFileSync(abs, 'utf-8'),
        };
      })
      .filter(Boolean);

    res.json({ files });
  });

  // Vite dev middleware or static production build
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.join(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`ScholarDesk server listening on http://localhost:${PORT}`);
  });
}

createApp().catch((err) => {
  console.error('Failed to start ScholarDesk server:', err);
  process.exit(1);
});
