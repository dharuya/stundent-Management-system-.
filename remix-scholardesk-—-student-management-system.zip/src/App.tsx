import { useCallback, useEffect, useRef, useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  FileCode2,
  GraduationCap,
  LayoutDashboard,
  LogOut,
  Plus,
  Users,
  X,
} from 'lucide-react';
import { DashboardView } from './components/DashboardView';
import { DeleteConfirmModal } from './components/DeleteConfirmModal';
import { DjangoGuideView } from './components/DjangoGuideView';
import { LoginView } from './components/LoginView';
import { StudentDirectoryView } from './components/StudentDirectoryView';
import { StudentFormModal } from './components/StudentFormModal';
import {
  ApiError,
  deleteStudent,
  fetchCurrentAdmin,
  fetchStudentStats,
  fetchStudents,
  logoutAdmin,
} from './services/api';
import type { AdminUser, Student, StudentStats } from './types/student';

type ActiveTab = 'dashboard' | 'students' | 'api-guide';

interface ToastNotice {
  id: number;
  type: 'success' | 'error';
  message: string;
}

export default function App() {
  const [authChecking, setAuthChecking] = useState(true);
  const [adminUser, setAdminUser] = useState<AdminUser | null>(null);
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');

  // Student Data & Stats
  const [students, setStudents] = useState<Student[]>([]);
  const [recentStudents, setRecentStudents] = useState<Student[]>([]);
  const [totalCount, setTotalCount] = useState(0);
  const [stats, setStats] = useState<StudentStats | null>(null);
  const [loadingData, setLoadingData] = useState(false);

  // Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [selectedDepartment, setSelectedDepartment] = useState('all');
  const [selectedYear, setSelectedYear] = useState('all');

  // Modals
  const [formModalOpen, setFormModalOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [deletingTarget, setDeletingTarget] = useState<Student | null>(null);
  const [deletingInProgress, setDeletingInProgress] = useState(false);

  // Toast feedback
  const [toast, setToast] = useState<ToastNotice | null>(null);
  const toastTimerRef = useRef<number | null>(null);

  const showToast = useCallback((type: 'success' | 'error', message: string) => {
    if (toastTimerRef.current) {
      window.clearTimeout(toastTimerRef.current);
    }
    setToast({ id: Date.now(), type, message });
    toastTimerRef.current = window.setTimeout(() => {
      setToast(null);
    }, 3800);
  }, []);

  // Debounce search query
  useEffect(() => {
    const timer = window.setTimeout(() => {
      setDebouncedSearch(searchQuery);
    }, 200);
    return () => window.clearTimeout(timer);
  }, [searchQuery]);

  // Verify existing admin session on mount
  useEffect(() => {
    let active = true;
    fetchCurrentAdmin()
      .then((user) => {
        if (active) setAdminUser(user);
      })
      .catch(() => {
        if (active) setAdminUser(null);
      })
      .finally(() => {
        if (active) setAuthChecking(false);
      });
    return () => {
      active = false;
    };
  }, []);

  const loadDashboardAndStudents = useCallback(async () => {
    if (!adminUser) return;
    setLoadingData(true);
    try {
      const [listRes, statsRes, unfilteredRes] = await Promise.all([
        fetchStudents({
          search: debouncedSearch,
          department: selectedDepartment,
          year: selectedYear,
        }),
        fetchStudentStats(),
        fetchStudents({}),
      ]);

      setStudents(listRes.results);
      setTotalCount(listRes.total_count);
      setStats(statsRes);
      setRecentStudents(unfilteredRes.results.slice(0, 5));
    } catch (err) {
      if (err instanceof ApiError && err.status === 401) {
        setAdminUser(null);
        showToast('error', 'Your admin session expired. Please sign in again.');
      } else {
        showToast('error', 'Unable to load student records from the database.');
      }
    } finally {
      setLoadingData(false);
    }
  }, [adminUser, debouncedSearch, selectedDepartment, selectedYear, showToast]);

  useEffect(() => {
    if (adminUser) {
      loadDashboardAndStudents();
    }
  }, [adminUser, loadDashboardAndStudents]);

  const handleLogout = async () => {
    await logoutAdmin();
    setAdminUser(null);
    setStudents([]);
    setRecentStudents([]);
    setStats(null);
    setActiveTab('dashboard');
  };

  const handleOpenAddModal = () => {
    setEditingStudent(null);
    setFormModalOpen(true);
  };

  const handleOpenEditModal = (student: Student) => {
    setEditingStudent(student);
    setFormModalOpen(true);
  };

  const handleStudentSaved = (student: Student, mode: 'create' | 'edit') => {
    setFormModalOpen(false);
    setEditingStudent(null);
    showToast(
      'success',
      mode === 'create'
        ? `Added ${student.name} (${student.roll_number}) to the directory.`
        : `Updated record for ${student.name} (${student.roll_number}).`
    );
    loadDashboardAndStudents();
  };

  const handleConfirmDelete = async () => {
    if (!deletingTarget) return;
    setDeletingInProgress(true);
    try {
      await deleteStudent(deletingTarget.id);
      showToast(
        'success',
        `Deleted ${deletingTarget.name} (${deletingTarget.roll_number}).`
      );
      setDeletingTarget(null);
      loadDashboardAndStudents();
    } catch (err) {
      if (err instanceof ApiError && err.status === 401) {
        setAdminUser(null);
        setDeletingTarget(null);
      } else {
        showToast('error', 'Could not delete student record. Please try again.');
      }
    } finally {
      setDeletingInProgress(false);
    }
  };

  const handleClearFilters = () => {
    setSearchQuery('');
    setDebouncedSearch('');
    setSelectedDepartment('all');
    setSelectedYear('all');
  };

  if (authChecking) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
        <div className="text-center space-y-3">
          <div className="w-10 h-10 rounded-lg bg-blue-700 text-white flex items-center justify-center mx-auto">
            <GraduationCap className="w-5 h-5" />
          </div>
          <p className="text-sm text-slate-600">Checking admin session...</p>
        </div>
      </div>
    );
  }

  if (!adminUser) {
    return (
      <LoginView
        onLoginSuccess={(user) => {
          setAdminUser(user);
          showToast('success', `Welcome back, ${user.username}.`);
        }}
      />
    );
  }

  const pageLabel =
    activeTab === 'dashboard'
      ? 'Dashboard'
      : activeTab === 'students'
      ? 'Student Directory'
      : 'REST API & Django';

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col lg:flex-row">
      {/* Desktop Sidebar (240px) */}
      <aside className="hidden lg:flex lg:w-60 lg:flex-col lg:fixed lg:inset-y-0 border-r border-slate-200 bg-white">
        <div className="h-16 px-5 border-b border-slate-200 flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-blue-700 text-white flex items-center justify-center shrink-0">
            <GraduationCap className="w-4 h-4" />
          </div>
          <span className="font-display text-base font-bold tracking-tight text-slate-900 whitespace-nowrap">
            ScholarDesk
          </span>
        </div>

        <nav aria-label="Primary navigation" className="flex-1 p-3 space-y-1">
          <button
            type="button"
            onClick={() => setActiveTab('dashboard')}
            className={`w-full min-h-[44px] px-3 py-2 rounded-lg text-sm font-medium flex items-center gap-3 transition-colors whitespace-nowrap ${
              activeTab === 'dashboard'
                ? 'bg-blue-50 text-blue-700'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <LayoutDashboard className="w-4 h-4 shrink-0" />
            <span>Dashboard</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('students')}
            className={`w-full min-h-[44px] px-3 py-2 rounded-lg text-sm font-medium flex items-center justify-between transition-colors whitespace-nowrap ${
              activeTab === 'students'
                ? 'bg-blue-50 text-blue-700'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <span className="flex items-center gap-3">
              <Users className="w-4 h-4 shrink-0" />
              <span>Students</span>
            </span>
            <span className="font-mono text-xs tabular-nums text-slate-500">
              {totalCount}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('api-guide')}
            className={`w-full min-h-[44px] px-3 py-2 rounded-lg text-sm font-medium flex items-center gap-3 transition-colors whitespace-nowrap ${
              activeTab === 'api-guide'
                ? 'bg-blue-50 text-blue-700'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <FileCode2 className="w-4 h-4 shrink-0" />
            <span>API & Django</span>
          </button>
        </nav>

        <div className="p-4 border-t border-slate-200 space-y-3">
          <div className="text-xs">
            <p className="font-medium text-slate-900 truncate">{adminUser.username}</p>
            <p className="text-slate-500 truncate">{adminUser.role} Account</p>
          </div>
          <button
            type="button"
            onClick={handleLogout}
            className="w-full min-h-[40px] px-3 py-2 rounded-lg border border-slate-200 bg-white text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors flex items-center justify-center gap-2"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>

      {/* Main Content Shell */}
      <div className="flex-1 lg:pl-60 flex flex-col min-h-screen">
        {/* Top Bar (Desktop sticky, Mobile static to respect 15% mobile sticky cap) */}
        <header className="h-14 lg:h-16 bg-white border-b border-slate-200 px-4 sm:px-6 flex items-center justify-between gap-4 lg:sticky lg:top-0 lg:z-30">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="lg:hidden w-8 h-8 rounded-lg bg-blue-700 text-white flex items-center justify-center shrink-0">
              <GraduationCap className="w-4 h-4" />
            </div>
            <span className="lg:hidden font-display text-base font-bold tracking-tight text-slate-900 whitespace-nowrap">
              ScholarDesk
            </span>
            <nav aria-label="Breadcrumb" className="hidden lg:flex items-center gap-2 text-sm">
              <span className="text-slate-500">ScholarDesk</span>
              <span className="text-slate-400" aria-hidden="true">
                /
              </span>
              <span className="font-medium text-slate-900">{pageLabel}</span>
            </nav>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={handleOpenAddModal}
              className="hidden lg:inline-flex min-h-[40px] px-3.5 py-2 rounded-lg bg-blue-700 text-xs font-medium text-white hover:bg-blue-800 transition-colors items-center gap-1.5 whitespace-nowrap shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>Add Student</span>
            </button>

            <button
              type="button"
              onClick={handleLogout}
              className="lg:hidden min-h-[44px] px-3 py-2 rounded-lg border border-slate-200 bg-white text-xs font-medium text-slate-700 hover:bg-slate-50 flex items-center gap-1.5 whitespace-nowrap shrink-0"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Sign Out</span>
            </button>
          </div>
        </header>

        {/* Main Viewport */}
        <main className="flex-1 px-4 sm:px-6 lg:px-8 py-6 pb-24 lg:pb-10 max-w-6xl w-full mx-auto">
          {toast && (
            <div
              role="status"
              aria-live="polite"
              className={`mb-5 rounded-xl border p-3.5 flex items-center justify-between gap-3 text-sm ${
                toast.type === 'success'
                  ? 'border-green-200 bg-green-50 text-green-900'
                  : 'border-red-200 bg-red-50 text-red-900'
              }`}
            >
              <div className="flex items-center gap-2.5 min-w-0">
                {toast.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 text-green-600 shrink-0" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
                )}
                <span className="truncate">{toast.message}</span>
              </div>
              <button
                type="button"
                onClick={() => setToast(null)}
                aria-label="Dismiss message"
                className="min-h-[32px] min-w-[32px] flex items-center justify-center rounded-md hover:bg-black/5 shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {activeTab === 'dashboard' && (
            <DashboardView
              stats={stats}
              recentStudents={recentStudents}
              loading={loadingData}
              onAddStudent={handleOpenAddModal}
              onViewAllStudents={() => setActiveTab('students')}
              onEditStudent={handleOpenEditModal}
            />
          )}

          {activeTab === 'students' && (
            <StudentDirectoryView
              students={students}
              totalCount={totalCount}
              loading={loadingData}
              searchQuery={searchQuery}
              selectedDepartment={selectedDepartment}
              selectedYear={selectedYear}
              onSearchChange={setSearchQuery}
              onDepartmentChange={setSelectedDepartment}
              onYearChange={setSelectedYear}
              onClearFilters={handleClearFilters}
              onAddStudent={handleOpenAddModal}
              onEditStudent={handleOpenEditModal}
              onDeleteStudent={setDeletingTarget}
            />
          )}

          {activeTab === 'api-guide' && <DjangoGuideView />}
        </main>
      </div>

      {/* Android Mobile Fixed Bottom Tab Bar (56px height — well within 15% mobile sticky cap) */}
      <nav
        aria-label="Mobile navigation"
        className="lg:hidden fixed bottom-0 left-0 right-0 z-40 h-14 bg-white/95 backdrop-blur-md border-t border-slate-200 grid grid-cols-4 items-center"
      >
        <button
          type="button"
          onClick={() => setActiveTab('dashboard')}
          className={`h-full flex flex-col items-center justify-center gap-0.5 text-[11px] font-medium transition-colors ${
            activeTab === 'dashboard' ? 'text-blue-700' : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <LayoutDashboard className="w-5 h-5" />
          <span>Dashboard</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('students')}
          className={`h-full flex flex-col items-center justify-center gap-0.5 text-[11px] font-medium transition-colors ${
            activeTab === 'students' ? 'text-blue-700' : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <Users className="w-5 h-5" />
          <span>Students</span>
        </button>

        <button
          type="button"
          onClick={handleOpenAddModal}
          className="h-full flex flex-col items-center justify-center gap-0.5 text-[11px] font-medium text-blue-700 hover:bg-blue-50/50 transition-colors"
        >
          <Plus className="w-5 h-5" />
          <span>Add New</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('api-guide')}
          className={`h-full flex flex-col items-center justify-center gap-0.5 text-[11px] font-medium transition-colors ${
            activeTab === 'api-guide' ? 'text-blue-700' : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <FileCode2 className="w-5 h-5" />
          <span>API Docs</span>
        </button>
      </nav>

      {/* Modals */}
      <StudentFormModal
        isOpen={formModalOpen}
        editingStudent={editingStudent}
        onClose={() => {
          setFormModalOpen(false);
          setEditingStudent(null);
        }}
        onSaved={handleStudentSaved}
      />

      <DeleteConfirmModal
        student={deletingTarget}
        deleting={deletingInProgress}
        onCancel={() => setDeletingTarget(null)}
        onConfirm={handleConfirmDelete}
      />
    </div>
  );
}
