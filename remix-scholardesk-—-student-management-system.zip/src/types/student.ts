export interface AdminUser {
  id: number;
  username: string;
  email: string;
  role: string;
}

export interface Student {
  id: number;
  name: string;
  roll_number: string;
  email: string;
  department: string;
  year: number;
  created_at: string;
  updated_at: string;
}

export interface StudentFormValues {
  name: string;
  roll_number: string;
  email: string;
  department: string;
  year: string;
}

export type StudentFieldErrors = Partial<
  Record<'name' | 'roll_number' | 'email' | 'department' | 'year' | 'non_field_errors', string>
>;

export interface StudentListResponse {
  count: number;
  total_count: number;
  results: Student[];
}

export interface StudentStats {
  total_students: number;
  department_count: number;
  departments: Array<{ department: string; count: number }>;
  years: Array<{ year: number; count: number }>;
}

export interface DjangoReferenceFile {
  path: string;
  content: string;
}

export const DEPARTMENTS = [
  'Computer Science',
  'Information Technology',
  'Electronics & Comm.',
  'Mechanical Engineering',
  'Civil Engineering',
  'Electrical Engineering',
  'Business Administration',
  'Data Science',
] as const;

export const ACADEMIC_YEARS = [
  { value: 1, label: '1st Year' },
  { value: 2, label: '2nd Year' },
  { value: 3, label: '3rd Year' },
  { value: 4, label: '4th Year' },
] as const;

export function formatYearLabel(year: number): string {
  const match = ACADEMIC_YEARS.find((y) => y.value === year);
  return match ? match.label : `Year ${year}`;
}
