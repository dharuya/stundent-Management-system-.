import { Pencil, Plus, Search, Trash2, X } from 'lucide-react';
import { ACADEMIC_YEARS, DEPARTMENTS, formatYearLabel } from '../types/student';
import type { Student } from '../types/student';

interface StudentDirectoryViewProps {
  students: Student[];
  totalCount: number;
  loading: boolean;
  searchQuery: string;
  selectedDepartment: string;
  selectedYear: string;
  onSearchChange: (value: string) => void;
  onDepartmentChange: (value: string) => void;
  onYearChange: (value: string) => void;
  onClearFilters: () => void;
  onAddStudent: () => void;
  onEditStudent: (student: Student) => void;
  onDeleteStudent: (student: Student) => void;
}

export function StudentDirectoryView({
  students,
  totalCount,
  loading,
  searchQuery,
  selectedDepartment,
  selectedYear,
  onSearchChange,
  onDepartmentChange,
  onYearChange,
  onClearFilters,
  onAddStudent,
  onEditStudent,
  onDeleteStudent,
}: StudentDirectoryViewProps) {
  const hasActiveFilter =
    searchQuery.trim().length > 0 || selectedDepartment !== 'all' || selectedYear !== 'all';

  return (
    <div className="space-y-5">
      {/* Header Row */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-slate-900 tracking-tight">
            Student Directory
          </h1>
          <p className="mt-1 text-sm text-slate-600 tabular-nums">
            Showing {students.length} of {totalCount} student{' '}
            {totalCount === 1 ? 'record' : 'records'}
          </p>
        </div>

        <button
          type="button"
          onClick={onAddStudent}
          className="min-h-[44px] px-4 py-2 rounded-lg bg-blue-700 text-sm font-medium text-white hover:bg-blue-800 transition-colors inline-flex items-center justify-center gap-2 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-700 focus-visible:ring-offset-2"
        >
          <Plus className="w-4 h-4" />
          <span>Add Student</span>
        </button>
      </div>

      {/* Search & Filters Toolbar */}
      <div className="rounded-xl border border-slate-200 bg-white p-4 space-y-3">
        <div className="flex flex-col md:flex-row gap-3">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Search by student name or roll number..."
              aria-label="Search students by name or roll number"
              className="w-full min-h-[44px] rounded-lg border border-slate-300 bg-white pl-10 pr-10 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-600/20"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => onSearchChange('')}
                aria-label="Clear search"
                className="absolute right-0.5 top-1/2 -translate-y-1/2 min-h-[44px] min-w-[44px] flex items-center justify-center text-slate-400 hover:text-slate-700 rounded-md"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Department Dropdown */}
          <div className="md:w-56">
            <label htmlFor="department-filter" className="sr-only">
              Filter by Department
            </label>
            <select
              id="department-filter"
              value={selectedDepartment}
              onChange={(e) => onDepartmentChange(e.target.value)}
              className="w-full min-h-[44px] rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-800 focus:border-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-600/20"
            >
              <option value="all">All Departments</option>
              {DEPARTMENTS.map((dept) => (
                <option key={dept} value={dept}>
                  {dept}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Year Filter Segmented Buttons */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
          <div
            role="group"
            aria-label="Filter by academic year"
            className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg overflow-x-auto max-w-full"
          >
            <button
              type="button"
              onClick={() => onYearChange('all')}
              className={`min-h-[36px] px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                selectedYear === 'all'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All Years
            </button>
            {ACADEMIC_YEARS.map((yr) => (
              <button
                key={yr.value}
                type="button"
                onClick={() => onYearChange(String(yr.value))}
                className={`min-h-[36px] px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  selectedYear === String(yr.value)
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {yr.label}
              </button>
            ))}
          </div>

          {hasActiveFilter && (
            <button
              type="button"
              onClick={onClearFilters}
              className="min-h-[36px] px-3 py-1.5 text-xs font-medium text-blue-700 hover:bg-blue-50 rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              Reset Filters
            </button>
          )}
        </div>
      </div>

      {/* Loading Skeleton */}
      {loading ? (
        <div className="rounded-xl border border-slate-200 bg-white divide-y divide-slate-100">
          {[1, 2, 3, 4, 5].map((row) => (
            <div key={row} className="p-4 flex items-center justify-between gap-4 animate-pulse">
              <div className="space-y-2 flex-1">
                <div className="h-4 w-44 bg-slate-200 rounded" />
                <div className="h-3 w-64 bg-slate-100 rounded" />
              </div>
              <div className="h-9 w-24 bg-slate-100 rounded" />
            </div>
          ))}
        </div>
      ) : students.length === 0 ? (
        /* Empty State */
        <div className="rounded-xl border border-slate-200 bg-white p-10 text-center">
          <h2 className="text-base font-semibold text-slate-900">
            {hasActiveFilter ? 'No matching student records' : 'No student records found'}
          </h2>
          <p className="mt-1.5 text-sm text-slate-600 max-w-md mx-auto">
            {hasActiveFilter
              ? 'Try adjusting your search query or clearing the department and year filters.'
              : 'Get started by adding your first student profile to the SQLite database.'}
          </p>
          <div className="mt-5 flex items-center justify-center gap-3">
            {hasActiveFilter ? (
              <button
                type="button"
                onClick={onClearFilters}
                className="min-h-[44px] px-4 py-2 rounded-lg border border-slate-300 bg-white text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors"
              >
                Clear Filters
              </button>
            ) : (
              <button
                type="button"
                onClick={onAddStudent}
                className="min-h-[44px] px-4 py-2 rounded-lg bg-blue-700 text-sm font-medium text-white hover:bg-blue-800 transition-colors inline-flex items-center gap-2"
              >
                <Plus className="w-4 h-4" />
                <span>Add First Student</span>
              </button>
            )}
          </div>
        </div>
      ) : (
        <>
          {/* Desktop Table View */}
          <div className="hidden md:block rounded-xl border border-slate-200 bg-white overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50/80 text-xs font-medium text-slate-600">
                    <th className="py-3 px-4">Roll Number</th>
                    <th className="py-3 px-4">Student Name</th>
                    <th className="py-3 px-4">Email Address</th>
                    <th className="py-3 px-4">Department</th>
                    <th className="py-3 px-4">Year</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {students.map((student) => (
                    <tr
                      key={student.id}
                      className="hover:bg-slate-50/80 transition-colors"
                    >
                      <td className="py-3 px-4 font-mono text-xs font-medium text-slate-800 tabular-nums whitespace-nowrap">
                        {student.roll_number}
                      </td>
                      <td className="py-3 px-4 font-medium text-slate-900">
                        {student.name}
                      </td>
                      <td className="py-3 px-4 text-slate-600">{student.email}</td>
                      <td className="py-3 px-4 text-slate-700">{student.department}</td>
                      <td className="py-3 px-4 text-slate-700 tabular-nums whitespace-nowrap">
                        {formatYearLabel(student.year)}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="inline-flex items-center justify-end gap-2">
                          <button
                            type="button"
                            onClick={() => onEditStudent(student)}
                            className="min-h-[36px] px-3 py-1.5 rounded-lg border border-slate-200 bg-white text-xs font-medium text-slate-700 hover:bg-slate-100 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                            <span>Edit</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => onDeleteStudent(student)}
                            className="min-h-[36px] px-3 py-1.5 rounded-lg border border-red-200 bg-white text-xs font-medium text-red-700 hover:bg-red-50 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>Delete</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Mobile-Friendly Card View (Android & Small Screens) */}
          <div className="md:hidden space-y-3">
            {students.map((student) => (
              <article
                key={student.id}
                className="rounded-xl border border-slate-200 bg-white p-4 space-y-3"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <h3 className="text-base font-semibold text-slate-900 truncate">
                      {student.name}
                    </h3>
                    <p className="mt-0.5 text-xs text-slate-600">
                      <span className="font-mono font-medium text-slate-800 tabular-nums">
                        {student.roll_number}
                      </span>{' '}
                      <span aria-hidden="true">·</span> {student.department}{' '}
                      <span aria-hidden="true">·</span> {formatYearLabel(student.year)}
                    </p>
                  </div>
                </div>

                <p className="text-sm text-slate-600 break-all">{student.email}</p>

                <div className="pt-2 border-t border-slate-100 grid grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    onClick={() => onEditStudent(student)}
                    className="min-h-[44px] px-3 py-2 rounded-lg border border-slate-300 bg-white text-sm font-medium text-slate-800 hover:bg-slate-50 active:bg-slate-100 transition-colors flex items-center justify-center gap-2"
                  >
                    <Pencil className="w-4 h-4" />
                    <span>Edit</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onDeleteStudent(student)}
                    className="min-h-[44px] px-3 py-2 rounded-lg border border-red-200 bg-red-50/40 text-sm font-medium text-red-700 hover:bg-red-50 active:bg-red-100 transition-colors flex items-center justify-center gap-2"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>Delete</span>
                  </button>
                </div>
              </article>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
