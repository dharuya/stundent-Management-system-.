import React, { useEffect, useState } from 'react';
import { AlertCircle, X } from 'lucide-react';
import { ApiError, createStudent, updateStudent } from '../services/api';
import { ACADEMIC_YEARS, DEPARTMENTS } from '../types/student';
import type { Student, StudentFieldErrors, StudentFormValues } from '../types/student';

interface StudentFormModalProps {
  isOpen: boolean;
  editingStudent: Student | null;
  onClose: () => void;
  onSaved: (student: Student, mode: 'create' | 'edit') => void;
}

const INITIAL_VALUES: StudentFormValues = {
  name: '',
  roll_number: '',
  email: '',
  department: DEPARTMENTS[0],
  year: '1',
};

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const ROLL_PATTERN = /^[A-Za-z0-9][A-Za-z0-9\-/]{1,30}$/;

export function StudentFormModal({
  isOpen,
  editingStudent,
  onClose,
  onSaved,
}: StudentFormModalProps) {
  const [values, setValues] = useState<StudentFormValues>(INITIAL_VALUES);
  const [errors, setErrors] = useState<StudentFieldErrors>({});
  const [formBannerError, setFormBannerError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!isOpen) return;
    setErrors({});
    setFormBannerError(null);
    if (editingStudent) {
      setValues({
        name: editingStudent.name,
        roll_number: editingStudent.roll_number,
        email: editingStudent.email,
        department: editingStudent.department,
        year: String(editingStudent.year),
      });
    } else {
      setValues(INITIAL_VALUES);
    }
  }, [isOpen, editingStudent]);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && !submitting) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, submitting, onClose]);

  if (!isOpen) return null;

  const validateClient = (): StudentFieldErrors => {
    const next: StudentFieldErrors = {};
    const name = values.name.trim();
    const roll = values.roll_number.trim();
    const email = values.email.trim();
    const department = values.department.trim();
    const yearNum = Number.parseInt(values.year, 10);

    if (!name) {
      next.name = 'Student name is required.';
    } else if (name.length < 2) {
      next.name = 'Name must be at least 2 characters.';
    }

    if (!roll) {
      next.roll_number = 'Roll number is required.';
    } else if (!ROLL_PATTERN.test(roll)) {
      next.roll_number = 'Use letters, numbers, hyphens, or slashes (e.g., CS2026-001).';
    }

    if (!email) {
      next.email = 'Email address is required.';
    } else if (!EMAIL_PATTERN.test(email)) {
      next.email = 'Enter a valid email address (e.g., student@university.edu).';
    }

    if (!department) {
      next.department = 'Please select a department.';
    }

    if (!Number.isInteger(yearNum) || yearNum < 1 || yearNum > 4) {
      next.year = 'Please choose an academic year (1st to 4th Year).';
    }

    return next;
  };

  const handleFieldChange = (field: keyof StudentFormValues, value: string) => {
    setValues((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: undefined }));
    }
    if (formBannerError) {
      setFormBannerError(null);
    }
  };

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setFormBannerError(null);

    const clientErrors = validateClient();
    if (Object.keys(clientErrors).length > 0) {
      setErrors(clientErrors);
      setFormBannerError('Please correct the highlighted fields before saving.');
      return;
    }

    setSubmitting(true);
    setErrors({});

    const payload = {
      name: values.name.trim(),
      roll_number: values.roll_number.trim().toUpperCase(),
      email: values.email.trim().toLowerCase(),
      department: values.department.trim(),
      year: Number.parseInt(values.year, 10),
    };

    try {
      if (editingStudent) {
        const updated = await updateStudent(editingStudent.id, payload);
        onSaved(updated, 'edit');
      } else {
        const created = await createStudent(payload);
        onSaved(created, 'create');
      }
    } catch (err) {
      if (err instanceof ApiError) {
        setErrors(err.fieldErrors);
        setFormBannerError(err.message);
      } else {
        setFormBannerError('Failed to save student record. Please try again.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  const isKnownDepartment = (DEPARTMENTS as readonly string[]).includes(values.department);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="student-modal-title"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/50 backdrop-blur-[2px] p-0 sm:p-4"
    >
      <div className="w-full sm:max-w-lg rounded-t-2xl sm:rounded-xl border border-slate-200 bg-white shadow-xl max-h-[92vh] flex flex-col overflow-hidden">
        {/* Drag Handle for Mobile */}
        <div className="sm:hidden pt-3 pb-1 flex justify-center">
          <div className="w-10 h-1 rounded-full bg-slate-300" />
        </div>

        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between gap-4">
          <div>
            <h2 id="student-modal-title" className="text-lg font-semibold text-slate-900">
              {editingStudent ? 'Edit Student Record' : 'Add New Student'}
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              {editingStudent
                ? `Updating profile for ${editingStudent.roll_number}`
                : 'Enter student details to store in SQLite.'}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            disabled={submitting}
            aria-label="Close modal"
            className="min-h-[44px] min-w-[44px] -mr-2 flex items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 hover:text-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} noValidate className="flex-1 overflow-y-auto p-5 space-y-4">
          {formBannerError && (
            <div
              role="alert"
              className="rounded-lg border border-red-200 bg-red-50 p-3 flex items-start gap-2 text-xs text-red-800"
            >
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
              <span>{formBannerError}</span>
            </div>
          )}

          <div>
            <label htmlFor="student-name" className="block text-sm font-medium text-slate-800 mb-1.5">
              Full Name <span className="text-red-600">*</span>
            </label>
            <input
              id="student-name"
              type="text"
              value={values.name}
              onChange={(e) => handleFieldChange('name', e.target.value)}
              placeholder="e.g., Aarav Sharma"
              aria-invalid={Boolean(errors.name)}
              className={`w-full min-h-[44px] rounded-lg border bg-white px-3.5 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600/20 ${
                errors.name ? 'border-red-400 focus:border-red-500' : 'border-slate-300 focus:border-blue-700'
              }`}
            />
            {errors.name && (
              <p className="mt-1.5 text-xs text-red-600 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                <span>{errors.name}</span>
              </p>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="student-roll" className="block text-sm font-medium text-slate-800 mb-1.5">
                Roll Number <span className="text-red-600">*</span>
              </label>
              <input
                id="student-roll"
                type="text"
                value={values.roll_number}
                onChange={(e) => handleFieldChange('roll_number', e.target.value)}
                placeholder="e.g., CS2026-045"
                aria-invalid={Boolean(errors.roll_number)}
                className={`w-full min-h-[44px] rounded-lg border bg-white px-3.5 py-2 font-mono text-sm text-slate-900 placeholder:text-slate-400 uppercase focus:outline-none focus:ring-2 focus:ring-blue-600/20 ${
                  errors.roll_number
                    ? 'border-red-400 focus:border-red-500'
                    : 'border-slate-300 focus:border-blue-700'
                }`}
              />
              {errors.roll_number && (
                <p className="mt-1.5 text-xs text-red-600 flex items-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  <span>{errors.roll_number}</span>
                </p>
              )}
            </div>

            <div>
              <label htmlFor="student-year" className="block text-sm font-medium text-slate-800 mb-1.5">
                Academic Year <span className="text-red-600">*</span>
              </label>
              <select
                id="student-year"
                value={values.year}
                onChange={(e) => handleFieldChange('year', e.target.value)}
                aria-invalid={Boolean(errors.year)}
                className={`w-full min-h-[44px] rounded-lg border bg-white px-3 py-2 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600/20 ${
                  errors.year ? 'border-red-400 focus:border-red-500' : 'border-slate-300 focus:border-blue-700'
                }`}
              >
                {ACADEMIC_YEARS.map((yr) => (
                  <option key={yr.value} value={String(yr.value)}>
                    {yr.label}
                  </option>
                ))}
              </select>
              {errors.year && (
                <p className="mt-1.5 text-xs text-red-600 flex items-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  <span>{errors.year}</span>
                </p>
              )}
            </div>
          </div>

          <div>
            <label htmlFor="student-email" className="block text-sm font-medium text-slate-800 mb-1.5">
              Email Address <span className="text-red-600">*</span>
            </label>
            <input
              id="student-email"
              type="email"
              value={values.email}
              onChange={(e) => handleFieldChange('email', e.target.value)}
              placeholder="e.g., student@university.edu"
              aria-invalid={Boolean(errors.email)}
              className={`w-full min-h-[44px] rounded-lg border bg-white px-3.5 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600/20 ${
                errors.email ? 'border-red-400 focus:border-red-500' : 'border-slate-300 focus:border-blue-700'
              }`}
            />
            {errors.email && (
              <p className="mt-1.5 text-xs text-red-600 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                <span>{errors.email}</span>
              </p>
            )}
          </div>

          <div>
            <label htmlFor="student-dept" className="block text-sm font-medium text-slate-800 mb-1.5">
              Department <span className="text-red-600">*</span>
            </label>
            <select
              id="student-dept"
              value={values.department}
              onChange={(e) => handleFieldChange('department', e.target.value)}
              aria-invalid={Boolean(errors.department)}
              className={`w-full min-h-[44px] rounded-lg border bg-white px-3 py-2 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600/20 ${
                errors.department
                  ? 'border-red-400 focus:border-red-500'
                  : 'border-slate-300 focus:border-blue-700'
              }`}
            >
              {!isKnownDepartment && values.department && (
                <option value={values.department}>{values.department}</option>
              )}
              {DEPARTMENTS.map((dept) => (
                <option key={dept} value={dept}>
                  {dept}
                </option>
              ))}
            </select>
            {errors.department && (
              <p className="mt-1.5 text-xs text-red-600 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                <span>{errors.department}</span>
              </p>
            )}
          </div>

          {/* Footer Actions */}
          <div className="pt-3 border-t border-slate-200 flex flex-col-reverse sm:flex-row sm:justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              disabled={submitting}
              className="min-h-[44px] px-4 py-2 rounded-lg border border-slate-300 bg-white text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="min-h-[44px] px-5 py-2 rounded-lg bg-blue-700 text-sm font-medium text-white hover:bg-blue-800 disabled:opacity-60 disabled:cursor-not-allowed transition-colors"
            >
              {submitting
                ? 'Saving...'
                : editingStudent
                ? 'Update Student'
                : 'Add Student'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
