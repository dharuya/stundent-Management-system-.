import React, { useState } from 'react';
import { AlertCircle, Eye, EyeOff, GraduationCap, Lock, ShieldCheck } from 'lucide-react';
import campusHallImage from '../assets/images/login_campus_hall_1794666108515.jpg';
import { ApiError, loginAdmin } from '../services/api';
import type { AdminUser } from '../types/student';

interface LoginViewProps {
  onLoginSuccess: (user: AdminUser) => void;
}

export function LoginView({ onLoginSuccess }: LoginViewProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = useState<{ username?: string; password?: string }>({});
  const [imageError, setImageError] = useState(false);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setErrorMessage(null);

    const nextErrors: { username?: string; password?: string } = {};
    if (!username.trim()) {
      nextErrors.username = 'Please enter your admin username.';
    }
    if (!password) {
      nextErrors.password = 'Please enter your password.';
    }

    if (Object.keys(nextErrors).length > 0) {
      setFieldErrors(nextErrors);
      return;
    }

    setFieldErrors({});
    setSubmitting(true);

    try {
      const result = await loginAdmin(username.trim(), password);
      onLoginSuccess(result.user);
    } catch (err) {
      if (err instanceof ApiError) {
        setErrorMessage(err.message);
      } else {
        setErrorMessage('Unable to reach the authentication server. Please try again.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleFillDemo = () => {
    setUsername('admin');
    setPassword('admin123');
    setFieldErrors({});
    setErrorMessage(null);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col lg:grid lg:grid-cols-12 items-stretch">
      {/* Left Architectural Panel (Desktop) */}
      <div className="hidden lg:flex lg:col-span-6 relative overflow-hidden bg-slate-900">
        {!imageError ? (
          <img
            src={campusHallImage}
            alt="University registrar building and sunlit library courtyard"
            referrerPolicy="no-referrer"
            onError={() => setImageError(true)}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-slate-800 via-slate-900 to-blue-950 flex items-center justify-center p-12">
            <GraduationCap className="w-20 h-20 text-slate-500" />
          </div>
        )}

        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/35 to-slate-950/20" />

        <div className="absolute bottom-0 left-0 right-0 p-10 text-white">
          <p className="text-xs font-medium tracking-wide text-slate-300 mb-3">
            Academic Registrar Portal
          </p>
          <h1 className="text-3xl font-semibold tracking-tight text-white max-w-md [text-wrap:balance]">
            Structured student records for modern campuses.
          </h1>
          <p className="mt-3 text-sm text-slate-300 max-w-md leading-relaxed">
            Manage enrollment, search cohorts by roll number, and keep department records synchronized with SQLite storage.
          </p>
        </div>
      </div>

      {/* Right Login Form Panel */}
      <div className="flex-1 lg:col-span-6 flex items-center justify-center p-6 sm:p-10">
        <div className="w-full max-w-md">
          <div className="mb-8">
            <div className="flex items-center gap-2.5 text-slate-900 mb-6">
              <div className="w-9 h-9 rounded-lg bg-blue-700 text-white flex items-center justify-center shrink-0">
                <GraduationCap className="w-5 h-5" />
              </div>
              <span className="font-display text-lg font-bold tracking-tight whitespace-nowrap">
                ScholarDesk
              </span>
            </div>

            <h2 className="text-2xl font-semibold text-slate-900 tracking-tight [text-wrap:balance]">
              Admin Sign In
            </h2>
            <p className="mt-1.5 text-sm text-slate-600">
              Sign in with your administrator credentials to view and manage student records.
            </p>
          </div>

          {errorMessage && (
            <div
              role="alert"
              className="mb-5 rounded-lg border border-red-200 bg-red-50 p-3.5 flex items-start gap-2.5 text-sm text-red-800"
            >
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} noValidate className="space-y-4">
            <div>
              <label
                htmlFor="login-username"
                className="block text-sm font-medium text-slate-800 mb-1.5"
              >
                Admin Username
              </label>
              <input
                id="login-username"
                type="text"
                autoComplete="username"
                value={username}
                onChange={(e) => {
                  setUsername(e.target.value);
                  if (fieldErrors.username) setFieldErrors((prev) => ({ ...prev, username: undefined }));
                }}
                placeholder="admin"
                aria-invalid={Boolean(fieldErrors.username)}
                className={`w-full min-h-[44px] rounded-lg border bg-white px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-600/20 ${
                  fieldErrors.username
                    ? 'border-red-400 focus:border-red-500'
                    : 'border-slate-300 focus:border-blue-700'
                }`}
              />
              {fieldErrors.username && (
                <p className="mt-1.5 text-xs text-red-600 flex items-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  <span>{fieldErrors.username}</span>
                </p>
              )}
            </div>

            <div>
              <label
                htmlFor="login-password"
                className="block text-sm font-medium text-slate-800 mb-1.5"
              >
                Password
              </label>
              <div className="relative">
                <input
                  id="login-password"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    if (fieldErrors.password) setFieldErrors((prev) => ({ ...prev, password: undefined }));
                  }}
                  placeholder="Enter your password"
                  aria-invalid={Boolean(fieldErrors.password)}
                  className={`w-full min-h-[44px] rounded-lg border bg-white pl-3.5 pr-12 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-600/20 ${
                    fieldErrors.password
                      ? 'border-red-400 focus:border-red-500'
                      : 'border-slate-300 focus:border-blue-700'
                  }`}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((prev) => !prev)}
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                  className="absolute right-0.5 top-1/2 -translate-y-1/2 min-h-[44px] min-w-[44px] flex items-center justify-center text-slate-500 hover:text-slate-800 rounded-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-700"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              {fieldErrors.password && (
                <p className="mt-1.5 text-xs text-red-600 flex items-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  <span>{fieldErrors.password}</span>
                </p>
              )}
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="w-full min-h-[46px] mt-2 rounded-lg bg-blue-700 px-4 py-2.5 text-sm font-medium text-white hover:bg-blue-800 disabled:opacity-60 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-700 focus-visible:ring-offset-2"
            >
              <Lock className="w-4 h-4" />
              <span>{submitting ? 'Signing in...' : 'Sign In'}</span>
            </button>
          </form>

          {/* Beginner-friendly Demo Credentials Helper */}
          <div className="mt-6 rounded-xl border border-slate-200 bg-white p-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="text-xs font-medium text-slate-900 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-blue-700 shrink-0" />
                  <span>Default Admin Credentials</span>
                </p>
                <p className="mt-1 text-xs text-slate-600 font-mono">
                  Username: <span className="text-slate-900 font-medium">admin</span> · Password:{' '}
                  <span className="text-slate-900 font-medium">admin123</span>
                </p>
              </div>
              <button
                type="button"
                onClick={handleFillDemo}
                className="min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-300 bg-slate-50 text-xs font-medium text-slate-800 hover:bg-slate-100 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-700"
              >
                Fill Credentials
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
