import { useEffect, useState } from 'react';
import { Check, Copy, Database, FileCode2, Server } from 'lucide-react';
import { fetchDjangoReference } from '../services/api';
import type { DjangoReferenceFile } from '../types/student';

const API_ENDPOINTS = [
  {
    method: 'POST',
    path: '/api/auth/login/',
    auth: 'Public',
    purpose: 'Authenticate admin username & password and receive a session token',
  },
  {
    method: 'POST',
    path: '/api/auth/logout/',
    auth: 'Admin',
    purpose: 'Invalidate the current admin session token',
  },
  {
    method: 'GET',
    path: '/api/auth/me/',
    auth: 'Admin',
    purpose: 'Verify active admin authentication state',
  },
  {
    method: 'GET',
    path: '/api/students/',
    auth: 'Admin',
    purpose: 'List all students with optional ?search=, ?department=, ?year= filters',
  },
  {
    method: 'GET',
    path: '/api/students/stats/',
    auth: 'Admin',
    purpose: 'Fetch total student count, department totals, and year breakdown',
  },
  {
    method: 'POST',
    path: '/api/students/',
    auth: 'Admin',
    purpose: 'Validate and insert a new student into SQLite',
  },
  {
    method: 'PUT',
    path: '/api/students/<id>/',
    auth: 'Admin',
    purpose: 'Update an existing student record with uniqueness validation',
  },
  {
    method: 'DELETE',
    path: '/api/students/<id>/',
    auth: 'Admin',
    purpose: 'Delete a student record by ID from SQLite',
  },
];

export function DjangoGuideView() {
  const [files, setFiles] = useState<DjangoReferenceFile[]>([]);
  const [selectedPath, setSelectedPath] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    let active = true;
    fetchDjangoReference()
      .then((loadedFiles) => {
        if (!active) return;
        setFiles(loadedFiles);
        if (loadedFiles.length > 0) {
          setSelectedPath(loadedFiles[0].path);
        }
      })
      .catch(() => {
        if (active) setFiles([]);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  const selectedFile = files.find((f) => f.path === selectedPath) || files[0] || null;

  const handleCopy = async () => {
    if (!selectedFile) return;
    try {
      await navigator.clipboard.writeText(selectedFile.content);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      // Ignore clipboard failure
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-slate-900 tracking-tight">
          REST API & Django Reference
        </h1>
        <p className="mt-1 text-sm text-slate-600">
          Inspect the REST API contract, SQLite schema, and included Python + Django REST Framework backend files.
        </p>
      </div>

      {/* Architecture Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="flex items-center gap-2 text-slate-900 font-semibold text-sm">
            <Database className="w-4 h-4 text-blue-700" />
            <span>SQLite Student Schema</span>
          </div>
          <p className="mt-1.5 text-xs text-slate-600 leading-relaxed">
            Records persist in <code className="font-mono text-slate-800">db.sqlite3</code> using
            unique constraints on <code className="font-mono text-slate-800">roll_number</code> and{' '}
            <code className="font-mono text-slate-800">email</code>, plus a year check constraint (1–4).
          </p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="flex items-center gap-2 text-slate-900 font-semibold text-sm">
            <Server className="w-4 h-4 text-blue-700" />
            <span>Protected DRF Endpoints</span>
          </div>
          <p className="mt-1.5 text-xs text-slate-600 leading-relaxed">
            Every student endpoint verifies the admin token via{' '}
            <code className="font-mono text-slate-800">Authorization: Token &lt;key&gt;</code> or
            HttpOnly session cookie, matching Django REST Framework conventions.
          </p>
        </div>
      </div>

      {/* Endpoints Reference Table */}
      <section className="rounded-xl border border-slate-200 bg-white overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200">
          <h2 className="text-base font-semibold text-slate-900">REST API Endpoints</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-xs font-medium text-slate-600">
                <th className="py-2.5 px-4">Method</th>
                <th className="py-2.5 px-4">Endpoint</th>
                <th className="py-2.5 px-4">Access</th>
                <th className="py-2.5 px-4">Description</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs sm:text-sm">
              {API_ENDPOINTS.map((ep) => (
                <tr key={`${ep.method}-${ep.path}`}>
                  <td className="py-2.5 px-4 font-mono text-xs font-semibold text-blue-700 whitespace-nowrap">
                    {ep.method}
                  </td>
                  <td className="py-2.5 px-4 font-mono text-xs text-slate-900 whitespace-nowrap">
                    {ep.path}
                  </td>
                  <td className="py-2.5 px-4 text-slate-600 whitespace-nowrap">{ep.auth}</td>
                  <td className="py-2.5 px-4 text-slate-600">{ep.purpose}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Django Project Files Browser */}
      <section className="rounded-xl border border-slate-200 bg-white overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <FileCode2 className="w-4 h-4 text-blue-700" />
            <h2 className="text-base font-semibold text-slate-900">
              Included Python & Django Project Files
            </h2>
          </div>

          {selectedFile && (
            <button
              type="button"
              onClick={handleCopy}
              className="min-h-[36px] px-3 py-1.5 rounded-lg border border-slate-200 bg-slate-50 text-xs font-medium text-slate-700 hover:bg-slate-100 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap shrink-0"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-green-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy File'}</span>
            </button>
          )}
        </div>

        {loading ? (
          <div className="p-6 text-sm text-slate-500">Loading Django backend files...</div>
        ) : files.length === 0 ? (
          <div className="p-6 text-sm text-slate-500">
            Django reference files are stored in the <code className="font-mono">/django_backend</code> directory.
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12">
            {/* File Selector List */}
            <div className="lg:col-span-4 border-b lg:border-b-0 lg:border-r border-slate-200 bg-slate-50/70 p-2 flex lg:flex-col gap-1 overflow-x-auto">
              {files.map((file) => {
                const isSelected = selectedFile?.path === file.path;
                return (
                  <button
                    key={file.path}
                    type="button"
                    onClick={() => setSelectedPath(file.path)}
                    className={`min-h-[40px] px-3 py-2 rounded-lg text-left font-mono text-xs transition-colors whitespace-nowrap shrink-0 ${
                      isSelected
                        ? 'bg-white text-blue-700 font-medium border border-slate-200 shadow-xs'
                        : 'text-slate-600 hover:bg-white/70 hover:text-slate-900'
                    }`}
                  >
                    {file.path.replace('django_backend/', '')}
                  </button>
                );
              })}
            </div>

            {/* File Content Viewer */}
            <div className="lg:col-span-8 bg-slate-950 text-slate-100 p-4 overflow-x-auto max-h-[420px]">
              <pre className="font-mono text-xs leading-relaxed">
                <code>{selectedFile?.content}</code>
              </pre>
            </div>
          </div>
        )}
      </section>
    </div>
  );
}
