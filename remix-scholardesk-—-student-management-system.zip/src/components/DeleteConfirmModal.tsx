import { AlertTriangle, X } from 'lucide-react';
import { formatYearLabel } from '../types/student';
import type { Student } from '../types/student';

interface DeleteConfirmModalProps {
  student: Student | null;
  deleting: boolean;
  onCancel: () => void;
  onConfirm: () => void;
}

export function DeleteConfirmModal({
  student,
  deleting,
  onCancel,
  onConfirm,
}: DeleteConfirmModalProps) {
  if (!student) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="delete-modal-title"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/50 backdrop-blur-[2px] p-0 sm:p-4"
    >
      <div className="w-full sm:max-w-md rounded-t-2xl sm:rounded-xl border border-slate-200 bg-white shadow-xl p-5 space-y-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-red-50 text-red-600 flex items-center justify-center shrink-0">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h2 id="delete-modal-title" className="text-base font-semibold text-slate-900">
                Delete Student Record
              </h2>
              <p className="text-xs text-slate-500">This action removes the record from SQLite.</p>
            </div>
          </div>

          <button
            type="button"
            onClick={onCancel}
            disabled={deleting}
            aria-label="Close confirmation"
            className="min-h-[44px] min-w-[44px] -mr-2 -mt-2 flex items-center justify-center rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="rounded-lg border border-slate-200 bg-slate-50 p-3.5 text-sm">
          <p className="font-medium text-slate-900">{student.name}</p>
          <p className="mt-0.5 text-xs text-slate-600">
            <span className="font-mono">{student.roll_number}</span>{' '}
            <span aria-hidden="true">·</span> {student.department}{' '}
            <span aria-hidden="true">·</span> {formatYearLabel(student.year)}
          </p>
        </div>

        <p className="text-sm text-slate-600">
          Are you sure you want to permanently delete this student record? This cannot be undone.
        </p>

        <div className="pt-2 flex flex-col-reverse sm:flex-row sm:justify-end gap-2.5">
          <button
            type="button"
            onClick={onCancel}
            disabled={deleting}
            className="min-h-[44px] px-4 py-2 rounded-lg border border-slate-300 bg-white text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={onConfirm}
            disabled={deleting}
            className="min-h-[44px] px-4 py-2 rounded-lg bg-red-600 text-sm font-medium text-white hover:bg-red-700 disabled:opacity-60 transition-colors"
          >
            {deleting ? 'Deleting...' : 'Delete Student'}
          </button>
        </div>
      </div>
    </div>
  );
}
