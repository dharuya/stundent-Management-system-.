import { ArrowRight, BookOpen, Plus, Users } from 'lucide-react';
import { formatYearLabel } from '../types/student';
import type { Student, StudentStats } from '../types/student';

interface DashboardViewProps {
  stats: StudentStats | null;
  recentStudents: Student[];
  loading: boolean;
  onAddStudent: () => void;
  onViewAllStudents: () => void;
  onEditStudent: (student: Student) => void;
}

export function DashboardView({
  stats,
  recentStudents,
  loading,
  onAddStudent,
  onViewAllStudents,
  onEditStudent,
}: DashboardViewProps) {
  const totalStudents = stats?.total_students ?? 0;
  const departmentCount = stats?.department_count ?? 0;
  const seniorCount = stats?.years.find((y) => y.year === 4)?.count ?? 0;

  if (loading && !stats) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {[1, 2, 3].map((item) => (
            <div key={item} className="h-28 rounded-xl border border-slate-200 bg-white p-5 animate-pulse">
              <div className="h-3.5 w-24 bg-slate-200 rounded mb-4" />
              <div className="h-8 w-16 bg-slate-200 rounded" />
            </div>
          ))}
        </div>
        <div className="h-64 rounded-xl border border-slate-200 bg-white p-5 animate-pulse" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header Summary Strip */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-slate-900 tracking-tight">
            Academic Dashboard
          </h1>
          <p className="mt-1 text-sm text-slate-600">
            Live student enrollment summary stored in your SQLite database.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onViewAllStudents}
            className="min-h-[44px] px-4 py-2 rounded-lg border border-slate-300 bg-white text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-700"
          >
            Browse Directory
          </button>
          <button
            type="button"
            onClick={onAddStudent}
            className="min-h-[44px] px-4 py-2 rounded-lg bg-blue-700 text-sm font-medium text-white hover:bg-blue-800 transition-colors flex items-center gap-2 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-700 focus-visible:ring-offset-2"
          >
            <Plus className="w-4 h-4" />
            <span>Add Student</span>
          </button>
        </div>
      </div>

      {/* Primary KPI Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-sm font-medium text-slate-600">Total Students</span>
            <Users className="w-4 h-4 text-blue-700" />
          </div>
          <p className="mt-3 font-mono text-3xl font-semibold text-slate-900 tabular-nums">
            {totalStudents}
          </p>
          <p className="mt-1 text-xs text-slate-500">Registered across all academic years</p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-sm font-medium text-slate-600">Departments</span>
            <BookOpen className="w-4 h-4 text-slate-500" />
          </div>
          <p className="mt-3 font-mono text-3xl font-semibold text-slate-900 tabular-nums">
            {departmentCount}
          </p>
          <p className="mt-1 text-xs text-slate-500">Active academic departments</p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-sm font-medium text-slate-600">Graduating Cohort</span>
            <span className="text-xs font-medium text-slate-500">4th Year</span>
          </div>
          <p className="mt-3 font-mono text-3xl font-semibold text-slate-900 tabular-nums">
            {seniorCount}
          </p>
          <p className="mt-1 text-xs text-slate-500">Final-year enrolled students</p>
        </div>
      </div>

      {/* Distribution Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Department Breakdown */}
        <section className="rounded-xl border border-slate-200 bg-white p-5">
          <h2 className="text-base font-semibold text-slate-900">Enrollment by Department</h2>
          <p className="mt-0.5 text-xs text-slate-500">
            Student headcount per academic department
          </p>

          {stats && stats.departments.length > 0 ? (
            <div className="mt-5 space-y-3.5">
              {stats.departments.map((item) => {
                const percentage = totalStudents > 0 ? Math.round((item.count / totalStudents) * 100) : 0;
                return (
                  <div key={item.department}>
                    <div className="flex items-center justify-between text-sm mb-1.5">
                      <span className="font-medium text-slate-800 truncate pr-3">
                        {item.department}
                      </span>
                      <span className="font-mono text-xs text-slate-600 tabular-nums shrink-0">
                        {item.count} {item.count === 1 ? 'student' : 'students'} · {percentage}%
                      </span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-slate-100 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-blue-700 transition-all duration-300"
                        style={{ width: `${Math.max(percentage, 4)}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="mt-6 py-8 text-center text-sm text-slate-500">
              No department records yet. Add your first student to see the distribution.
            </div>
          )}
        </section>

        {/* Academic Year Breakdown */}
        <section className="rounded-xl border border-slate-200 bg-white p-5">
          <h2 className="text-base font-semibold text-slate-900">Students by Academic Year</h2>
          <p className="mt-0.5 text-xs text-slate-500">
            Distribution from 1st Year through 4th Year
          </p>

          <div className="mt-5 space-y-3.5">
            {[1, 2, 3, 4].map((yearNum) => {
              const found = stats?.years.find((y) => y.year === yearNum);
              const count = found?.count ?? 0;
              const percentage = totalStudents > 0 ? Math.round((count / totalStudents) * 100) : 0;

              return (
                <div key={yearNum}>
                  <div className="flex items-center justify-between text-sm mb-1.5">
                    <span className="font-medium text-slate-800">{formatYearLabel(yearNum)}</span>
                    <span className="font-mono text-xs text-slate-600 tabular-nums">
                      {count} {count === 1 ? 'student' : 'students'} · {percentage}%
                    </span>
                  </div>
                  <div className="h-2 w-full rounded-full bg-slate-100 overflow-hidden">
                    <div
                      className="h-full rounded-full bg-slate-700 transition-all duration-300"
                      style={{ width: count > 0 ? `${Math.max(percentage, 4)}%` : '0%' }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      </div>

      {/* Recently Added Students */}
      <section className="rounded-xl border border-slate-200 bg-white overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-semibold text-slate-900">Recently Added Students</h2>
            <p className="text-xs text-slate-500">Latest student profiles saved in SQLite</p>
          </div>
          <button
            type="button"
            onClick={onViewAllStudents}
            className="min-h-[40px] px-3 py-1.5 rounded-lg text-xs font-medium text-blue-700 hover:bg-blue-50 transition-colors flex items-center gap-1 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-700"
          >
            <span>View All</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {recentStudents.length === 0 ? (
          <div className="p-8 text-center">
            <p className="text-sm text-slate-600">No students have been added yet.</p>
            <button
              type="button"
              onClick={onAddStudent}
              className="mt-3 min-h-[44px] inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-blue-700 text-sm font-medium text-white hover:bg-blue-800 transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Add First Student</span>
            </button>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {recentStudents.map((student) => (
              <div
                key={student.id}
                className="px-5 py-3.5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 hover:bg-slate-50/80 transition-colors"
              >
                <div className="min-w-0">
                  <div className="flex items-center gap-2.5">
                    <span className="font-medium text-sm text-slate-900 truncate">
                      {student.name}
                    </span>
                    <span className="font-mono text-xs text-slate-500 tabular-nums shrink-0">
                      {student.roll_number}
                    </span>
                  </div>
                  <p className="mt-0.5 text-xs text-slate-500 truncate">
                    {student.department} <span aria-hidden="true">·</span>{' '}
                    {formatYearLabel(student.year)} <span aria-hidden="true">·</span>{' '}
                    {student.email}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => onEditStudent(student)}
                  className="self-start sm:self-center min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-200 bg-white text-xs font-medium text-slate-700 hover:bg-slate-100 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-700"
                >
                  Edit Record
                </button>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
