import type {
  AdminUser,
  DjangoReferenceFile,
  Student,
  StudentFieldErrors,
  StudentListResponse,
  StudentStats,
} from '../types/student';

const TOKEN_STORAGE_KEY = 'scholardesk_admin_token';

export class ApiError extends Error {
  status: number;
  fieldErrors: StudentFieldErrors;

  constructor(message: string, status: number, fieldErrors: StudentFieldErrors = {}) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.fieldErrors = fieldErrors;
  }
}

export function getStoredToken(): string | null {
  try {
    return window.localStorage.getItem(TOKEN_STORAGE_KEY);
  } catch {
    return null;
  }
}

export function setStoredToken(token: string | null): void {
  try {
    if (token) {
      window.localStorage.setItem(TOKEN_STORAGE_KEY, token);
    } else {
      window.localStorage.removeItem(TOKEN_STORAGE_KEY);
    }
  } catch {
    // Ignore storage errors in restricted contexts
  }
}

function parseFieldErrors(data: unknown): StudentFieldErrors {
  if (!data || typeof data !== 'object') return {};
  const record = data as Record<string, unknown>;
  const mapped: StudentFieldErrors = {};

  const keys: Array<keyof StudentFieldErrors> = [
    'name',
    'roll_number',
    'email',
    'department',
    'year',
    'non_field_errors',
  ];

  for (const key of keys) {
    const val = record[key];
    if (Array.isArray(val) && val.length > 0) {
      mapped[key] = String(val[0]);
    } else if (typeof val === 'string' && val.trim()) {
      mapped[key] = val;
    }
  }

  return mapped;
}

async function apiFetch<T>(url: string, options: RequestInit = {}): Promise<T> {
  const token = getStoredToken();
  const headers = new Headers(options.headers || {});
  if (!headers.has('Content-Type') && options.body) {
    headers.set('Content-Type', 'application/json');
  }
  if (token) {
    headers.set('Authorization', `Token ${token}`);
  }

  const response = await fetch(url, {
    ...options,
    headers,
    credentials: 'include',
  });

  if (response.status === 204) {
    return undefined as T;
  }

  let data: unknown = null;
  const contentType = response.headers.get('content-type') || '';
  if (contentType.includes('application/json')) {
    data = await response.json();
  }

  if (!response.ok) {
    if (response.status === 401) {
      setStoredToken(null);
    }
    const fieldErrors = parseFieldErrors(data);
    const detail =
      data && typeof data === 'object' && 'detail' in data
        ? String((data as { detail: unknown }).detail)
        : `Request failed with status ${response.status}`;
    throw new ApiError(detail, response.status, fieldErrors);
  }

  return data as T;
}

export async function loginAdmin(
  username: string,
  password: string
): Promise<{ token: string; user: AdminUser }> {
  const result = await apiFetch<{ token: string; user: AdminUser }>('/api/auth/login/', {
    method: 'POST',
    body: JSON.stringify({ username, password }),
  });
  setStoredToken(result.token);
  return result;
}

export async function logoutAdmin(): Promise<void> {
  try {
    await apiFetch<{ detail: string }>('/api/auth/logout/', {
      method: 'POST',
    });
  } finally {
    setStoredToken(null);
  }
}

export async function fetchCurrentAdmin(): Promise<AdminUser> {
  const result = await apiFetch<{ user: AdminUser }>('/api/auth/me/');
  return result.user;
}

export async function fetchStudents(params: {
  search?: string;
  department?: string;
  year?: string;
}): Promise<StudentListResponse> {
  const query = new URLSearchParams();
  if (params.search?.trim()) {
    query.set('search', params.search.trim());
  }
  if (params.department && params.department !== 'all') {
    query.set('department', params.department);
  }
  if (params.year && params.year !== 'all') {
    query.set('year', params.year);
  }
  const qs = query.toString();
  return apiFetch<StudentListResponse>(`/api/students/${qs ? `?${qs}` : ''}`);
}

export async function fetchStudentStats(): Promise<StudentStats> {
  return apiFetch<StudentStats>('/api/students/stats/');
}

export async function createStudent(payload: {
  name: string;
  roll_number: string;
  email: string;
  department: string;
  year: number;
}): Promise<Student> {
  return apiFetch<Student>('/api/students/', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

export async function updateStudent(
  id: number,
  payload: {
    name: string;
    roll_number: string;
    email: string;
    department: string;
    year: number;
  }
): Promise<Student> {
  return apiFetch<Student>(`/api/students/${id}/`, {
    method: 'PUT',
    body: JSON.stringify(payload),
  });
}

export async function deleteStudent(id: number): Promise<void> {
  return apiFetch<void>(`/api/students/${id}/`, {
    method: 'DELETE',
  });
}

export async function fetchDjangoReference(): Promise<DjangoReferenceFile[]> {
  const res = await apiFetch<{ files: DjangoReferenceFile[] }>('/api/django-reference/');
  return res.files;
}
