# ScholarDesk — Python & Django REST Framework Backend

This folder contains the complete, beginner-friendly Django + Django REST Framework + SQLite backend for the Student Management System.

## Quick Start (Local Python Environment)

```bash
cd django_backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

python manage.py makemigrations students
python manage.py migrate
python manage.py createsuperuser  # Create your admin username & password
python manage.py runserver 8000
```

## REST API Endpoints

| Method | Endpoint | Auth | Description |
| :--- | :--- | :--- | :--- |
| `POST` | `/api/auth/login/` | Public | Admin login (`username`, `password`) -> returns DRF Token |
| `POST` | `/api/auth/logout/` | Admin | Revokes active DRF Token |
| `GET` | `/api/auth/me/` | Admin | Returns authenticated admin user profile |
| `GET` | `/api/students/` | Admin | List all students (`?search=`, `?department=`, `?year=`) |
| `GET` | `/api/students/stats/` | Admin | Dashboard total count and breakdowns |
| `POST` | `/api/students/` | Admin | Create a new student record |
| `GET` | `/api/students/<id>/` | Admin | Retrieve one student record |
| `PUT` / `PATCH` | `/api/students/<id>/` | Admin | Update student information |
| `DELETE` | `/api/students/<id>/` | Admin | Delete student record |
