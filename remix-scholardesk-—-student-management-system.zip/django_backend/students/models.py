from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator


class Student(models.Model):
    """Represents a registered student in the SQLite database."""

    YEAR_CHOICES = [
        (1, '1st Year'),
        (2, '2nd Year'),
        (3, '3rd Year'),
        (4, '4th Year'),
    ]

    name = models.CharField(max_length=120)
    roll_number = models.CharField(max_length=32, unique=True, db_index=True)
    email = models.EmailField(unique=True)
    department = models.CharField(max_length=80)
    year = models.PositiveSmallIntegerField(
        choices=YEAR_CHOICES,
        validators=[MinValueValidator(1), MaxValueValidator(4)],
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at', 'name']

    def __str__(self):
        return f"{self.roll_number} — {self.name}"
