from django.urls import path, include
from rest_framework.routers import DefaultRouter

from .views import (
    AdminLoginView,
    AdminLogoutView,
    AdminMeView,
    StudentViewSet,
)

router = DefaultRouter()
router.register(r'students', StudentViewSet, basename='student')

urlpatterns = [
    path('auth/login/', AdminLoginView.as_view(), name='admin-login'),
    path('auth/logout/', AdminLogoutView.as_view(), name='admin-logout'),
    path('auth/me/', AdminMeView.as_view(), name='admin-me'),
    path('', include(router.urls)),
]
