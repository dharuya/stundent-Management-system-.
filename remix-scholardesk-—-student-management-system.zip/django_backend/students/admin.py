from django.contrib import admin
from .models import Student


@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ('roll_number', 'name', 'email', 'department', 'year', 'created_at')
    list_filter = ('department', 'year')
    search_fields = ('name', 'roll_number', 'email')
    ordering = ('-created_at',)
