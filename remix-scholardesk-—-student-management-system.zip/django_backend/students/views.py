from django.contrib.auth import authenticate
from django.db.models import Count, Q
from rest_framework import permissions, status, viewsets
from rest_framework.authtoken.models import Token
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import Student
from .serializers import StudentSerializer


class AdminLoginView(APIView):
    """POST /api/auth/login/ — Authenticates an admin user and issues a DRF Token."""
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        username = (request.data.get('username') or '').strip()
        password = request.data.get('password') or ''

        if not username or not password:
            return Response(
                {'detail': 'Both username and password are required.'},
                status=status.HTTP_400_BAD_REQUEST,
            )

        user = authenticate(username=username, password=password)
        if not user or not user.is_staff:
            return Response(
                {'detail': 'Invalid admin credentials.'},
                status=status.HTTP_401_UNAUTHORIZED,
            )

        token, _ = Token.objects.get_or_create(user=user)
        return Response({
            'token': token.key,
            'user': {
                'id': user.id,
                'username': user.username,
                'email': user.email,
                'role': 'Admin' if user.is_superuser else 'Staff',
            },
        })


class AdminLogoutView(APIView):
    """POST /api/auth/logout/ — Revokes the active DRF Token."""
    permission_classes = [permissions.IsAdminUser]

    def post(self, request):
        if request.auth:
            request.auth.delete()
        return Response({'detail': 'Signed out successfully.'})


class AdminMeView(APIView):
    """GET /api/auth/me/ — Returns the authenticated admin user."""
    permission_classes = [permissions.IsAdminUser]

    def get(self, request):
        user = request.user
        return Response({
            'user': {
                'id': user.id,
                'username': user.username,
                'email': user.email,
                'role': 'Admin' if user.is_superuser else 'Staff',
            }
        })


class StudentViewSet(viewsets.ModelViewSet):
    """
    Protected CRUD endpoints for student records:
    - GET    /api/students/       (supports ?search=, ?department=, ?year=)
    - POST   /api/students/
    - GET    /api/students/<id>/
    - PUT    /api/students/<id>/
    - PATCH  /api/students/<id>/
    - DELETE /api/students/<id>/
    - GET    /api/students/stats/
    """
    serializer_class = StudentSerializer
    permission_classes = [permissions.IsAdminUser]

    def get_queryset(self):
        queryset = Student.objects.all()
        search = (self.request.query_params.get('search') or '').strip()
        department = (self.request.query_params.get('department') or '').strip()
        year = (self.request.query_params.get('year') or '').strip()

        if search:
            queryset = queryset.filter(
                Q(name__icontains=search) | Q(roll_number__icontains=search)
            )
        if department and department != 'all':
            queryset = queryset.filter(department__iexact=department)
        if year and year != 'all':
            queryset = queryset.filter(year=year)

        return queryset

    def list(self, request, *args, **kwargs):
        queryset = self.get_queryset()
        serializer = self.get_serializer(queryset, many=True)
        total_count = Student.objects.count()
        return Response({
            'count': queryset.count(),
            'total_count': total_count,
            'results': serializer.data,
        })

    @action(detail=False, methods=['get'])
    def stats(self, request):
        total = Student.objects.count()
        departments = list(
            Student.objects.values('department')
            .annotate(count=Count('id'))
            .order_by('-count', 'department')
        )
        years = list(
            Student.objects.values('year')
            .annotate(count=Count('id'))
            .order_by('year')
        )
        return Response({
            'total_students': total,
            'department_count': len(departments),
            'departments': departments,
            'years': years,
        })
