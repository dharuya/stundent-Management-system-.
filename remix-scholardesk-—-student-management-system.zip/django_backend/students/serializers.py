from rest_framework import serializers
from .models import Student


class StudentSerializer(serializers.ModelSerializer):
    """Validates and serializes Student records for REST API endpoints."""

    class Meta:
        model = Student
        fields = [
            'id',
            'name',
            'roll_number',
            'email',
            'department',
            'year',
            'created_at',
            'updated_at',
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']

    def validate_name(self, value: str) -> str:
        cleaned = value.strip()
        if len(cleaned) < 2:
            raise serializers.ValidationError('Student name must be at least 2 characters.')
        return cleaned

    def validate_roll_number(self, value: str) -> str:
        cleaned = value.strip().upper()
        if len(cleaned) < 2:
            raise serializers.ValidationError('Roll number must be at least 2 characters.')
        qs = Student.objects.filter(roll_number__iexact=cleaned)
        if self.instance:
            qs = qs.exclude(pk=self.instance.pk)
        if qs.exists():
            raise serializers.ValidationError('A student with this roll number already exists.')
        return cleaned

    def validate_email(self, value: str) -> str:
        cleaned = value.strip().lower()
        qs = Student.objects.filter(email__iexact=cleaned)
        if self.instance:
            qs = qs.exclude(pk=self.instance.pk)
        if qs.exists():
            raise serializers.ValidationError('A student with this email address already exists.')
        return cleaned

    def validate_department(self, value: str) -> str:
        cleaned = value.strip()
        if not cleaned:
            raise serializers.ValidationError('Department is required.')
        return cleaned
